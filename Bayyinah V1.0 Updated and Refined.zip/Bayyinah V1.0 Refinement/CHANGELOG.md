# Changelog

All notable changes to Bayyinah are documented here. Format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/); versioning follows
[SemVer](https://semver.org/spec/v2.0.0.html).

The modular refactor of 0.2.0 was organised as the eight-phase Al-Baqarah
roadmap. Each phase added one architectural slice behind the existing
reference implementation without touching it — the parity invariant
(`bayyinah.scan_pdf == bayyinah_v0.scan_pdf` on every Phase 0 fixture) has
held across every phase.

## [1.0.0] — 2026-04-23

First stable release. Phase 22 — Final Release Packaging. Al-Baqarah
2:286: *"Rabbana la tu'akhidhna in nasina aw akhta'na"* — Our Lord, do
not impose blame upon us if we have forgotten or erred. The release
is the ring closed on the twenty-two-phase Al-Baqarah roadmap: the
scanner now holds one contract for twelve file formats, degrades
gracefully under configured ceilings, and never returns silent-clean
on a file it could not identify.

### Added

- **Release status**: PyPI classifier promoted from
  `Development Status :: 3 - Alpha` to
  `Development Status :: 5 - Production/Stable`.
- **GitHub Actions CI** (`.github/workflows/ci.yml`). Matrix across
  Python 3.10 / 3.11 / 3.12 / 3.13. Every push and PR installs the
  package with dev extras, regenerates the fixture corpus, runs the
  full pytest suite, and executes the PDF byte-identical parity sweep
  against `bayyinah_v0` plus the additive-only public-surface check.
- **`CONTRIBUTING.md`**. Six-step "adding a new format" guide,
  five-step workflow restated, ground rules (additive-only,
  ceilings-in-`ScanLimits`, no silent-clean on `UNKNOWN`, emit
  `scan_limited` rather than raise). The contract future contributors
  work to.
- **README.md** — quick-start examples, 12-format support table with
  per-format mechanisms, `ScanLimits` configuration table with
  defaults, fallback-witness explanation, architecture callout
  refreshed to 1.0.

### Supported formats (twelve)

One contract — `BaseAnalyzer.scan(path) -> IntegrityReport` — applied
uniformly across every format:

- **PDF** (`ZahirTextAnalyzer` + `BatinObjectAnalyzer`) — text-layer
  zahir/batin (zero-width, TAG, bidi, homoglyphs, invisible render
  modes, microscopic fonts, white-on-white, overlapping text) +
  object-layer batin (JavaScript, OpenAction, additional actions,
  launch actions, embedded files, FileAttachment annotations,
  incremental updates, metadata anomalies, hidden OCGs, adversarial
  ToUnicode CMap).
- **DOCX** (`DocxAnalyzer`) — tracked changes, comments, hidden text,
  OLE, external-target relationships.
- **HTML** (`HtmlAnalyzer`) — CSS-hidden text, off-screen absolute
  positioning, `<script>` / `on*` handlers, data-URI payloads.
- **XLSX** (`XlsxAnalyzer`) — hidden sheets / rows / columns,
  white-on-white cells, formula injection, external links.
- **PPTX** (`PptxAnalyzer`) — hidden slides, off-canvas shapes,
  embedded OLE, speaker-notes payloads.
- **EML** (`EmlAnalyzer`) — bodyless envelopes, mismatched
  `From` / `Return-Path`, suspicious attachments, nested
  `message/rfc822` recursion.
- **CSV** (`CsvAnalyzer`) — formula injection prefixes
  (`=`, `+`, `-`, `@`, tab, CR), Unicode concealment in cells.
- **JSON** (`JsonAnalyzer`) — prompt-injection strings, base64 blobs,
  zero-width / TAG characters in values.
- **Markdown / code / plain text** (`TextFileAnalyzer`) — zero-width,
  TAG, bidi, homoglyphs, invisible HTML spans.
- **PNG / JPEG / GIF / BMP / TIFF / WebP** (`ImageAnalyzer`) — LSB
  steganography, trailing payloads, EXIF anomalies, embedded text
  layers.
- **SVG** (`SvgAnalyzer`) — `<script>` tags, `on*` handlers,
  external-ref `<use>`, foreign-object HTML, off-screen text.
- **Unknown** (`FallbackAnalyzer`, Phase 21) — universal witness of
  last resort. Every file the router cannot classify surfaces as
  `unknown_format` with forensic metadata (magic-byte prefix,
  extension, size, head preview in hex + ASCII) and
  `scan_incomplete=True`. Closes the silent-clean failure mode.

### Production hardening (Phase 21, carried forward)

- **`ScanLimits`** — single declaration point for every capacity
  ceiling (`max_file_size_bytes`, `max_recursion_depth`,
  `max_csv_rows`, `max_field_length`, `max_eml_attachments`). Frozen
  dataclass; installed per-scan via a thread-local `limits_context`
  so concurrent scans with different limits do not clobber each other.
  Ceiling `0` opts out.
- **`scan_limited` finding** (tier 3, severity 0.0, non-deducting).
  Every analyzer that hits a ceiling emits one, sets
  `scan_incomplete=True`, and returns whatever findings it already
  gathered — graceful degradation under adversarial sizing.

### Preserved (Additive-Only Invariant)

`bayyinah_v0.py` and `bayyinah_v0_1.py` remain byte-identical to their
0.1.0 releases. Every public symbol introduced in the 0.2.x / 0.3.x
refactor series is append-only — no rename, no removal. PDF parity
against `bayyinah_v0` is byte-identical across every Phase 0 fixture
(clean, positive_combined, eight text-layer, seven object-layer) and
re-verified on every CI run.

### Tested against

1283 pytest cases across domain, infrastructure, analyzer, application,
fixture, and end-to-end integration suites. Byte-identical PDF parity
holds on 17 / 17 Phase 0 fixtures. Every adversarial fixture (PDF,
DOCX, HTML, XLSX, PPTX, EML, CSV, JSON, text, image, SVG) asserts its
exact declared mechanism set.

## [0.3.0] — 2026-04-22

Phase 21 — Production Hardening. Al-Baqarah 2:286: *"Allah does not burden
a soul beyond its capacity."* The scanner must not burden itself beyond
its configured capacity.

### Added

- **Universal Fallback Analyzer** (`analyzers/fallback_analyzer.py`). Any
  file the `FileRouter` leaves unclassified as `FileKind.UNKNOWN` now
  surfaces one `unknown_format` finding (tier 3, non-deducting) carrying
  forensic metadata: declared extension, file size, magic-byte prefix
  (first 16 bytes, hex-encoded), head-preview in both hex and
  printable-ASCII (first 512 bytes). Scan is marked `scan_incomplete=True`
  so the 0.5 `SCAN_INCOMPLETE_CLAMP` applies. Closes the silent-clean
  failure mode: a file we could not identify no longer slips through as
  score 1.0 with zero findings. Al-Baqarah 2:143 applied to format
  classification.
- **Configurable safety limits** (`domain/config.py` — `ScanLimits`,
  `DEFAULT_LIMITS`, `limits_context`, `get_current_limits`,
  `set_current_limits`). Five frozen-dataclass ceilings declared once:
  - `max_file_size_bytes` (default 256 MB) — `ScanService` pre-flight
    before any analyzer runs. Oversize files short-circuit with a single
    `scan_limited` finding.
  - `max_recursion_depth` (default 5) — `EmlAnalyzer` nested-message
    recursion. Supersedes the prior hard-coded 3.
  - `max_csv_rows` (default 200 000) — `CsvAnalyzer` row walk.
  - `max_field_length` (default 4 MiB) — `CsvAnalyzer` per-cell Unicode
    concealment cut-off.
  - `max_eml_attachments` (default 64) — `EmlAnalyzer` per-message cap.
  Limits flow into analyzers via a thread-local context manager so the
  `BaseAnalyzer.scan(pdf_path) -> IntegrityReport` contract is unchanged.
  Every analyzer that hits a ceiling emits a `scan_limited` finding
  (tier 3, severity 0.0, non-deducting), sets `scan_incomplete=True`, and
  returns whatever findings it already gathered — graceful degradation,
  never crashes.
- **New mechanisms**: `unknown_format`, `scan_limited`. Both are batin,
  tier 3, severity 0.00 (non-deducting; rely on `scan_incomplete` clamp).
- **Public API surface**: `bayyinah.FallbackAnalyzer`,
  `bayyinah.ScanLimits`, `bayyinah.DEFAULT_LIMITS`,
  `bayyinah.limits_context`, `bayyinah.get_current_limits`,
  `bayyinah.set_current_limits`, `bayyinah.default_registry`.
- **`ScanService(limits=ScanLimits(...))`** — per-service limit override.
  The limits are scoped to the duration of each `scan()` call via
  `limits_context`, so concurrent scans with different limits do not
  clobber each other.

### Preserved (Additive-Only Invariant)

- `bayyinah_v0.py` and `bayyinah_v0_1.py` unchanged. PDF parity
  byte-identical across every Phase 0 fixture. `FallbackAnalyzer` never
  fires on an identified format (`supported_kinds = {FileKind.UNKNOWN}`),
  and the per-format analyzers never see the `scan_limited` mechanism
  unless a caller explicitly tightens `ScanLimits` past the default.

## [0.2.0] — 2026-04-22

### Added

- **Public Python API** (`bayyinah/__init__.py`). `from bayyinah import
  scan_pdf` is now the canonical entry point. Re-exports the orchestrator,
  analyzers, formatters, and domain types.
- **CLI** (`cli/main.py`) with subcommand surface:
  `bayyinah scan <file> [--json | --summary | --quiet]`. Exit codes
  preserved byte-for-byte from v0/v0.1 (0 / 1 / 2 for clean / findings /
  error). `bayyinah --version` added.
- **Domain layer** (`domain/`). Pure data types and scoring primitives —
  `Finding`, `IntegrityReport`, `compute_muwazana_score`, `tamyiz_verdict`,
  `apply_scan_incomplete_clamp`, `BayyinahError` hierarchy. No I/O, no
  parser dependencies.
- **Infrastructure layer** (`infrastructure/`). `PDFClient` wraps the
  pymupdf + pypdf handles with context-manager safety. `FileRouter`
  detects PDF / DOCX / HTML / JSON / image / code by magic bytes and
  extension, flags polyglot files. `TerminalReportFormatter`,
  `JsonReportFormatter`, `PlainLanguageFormatter` — all byte-identical to
  v0.1's inline `format_text_report` / `plain_language_summary`.
- **Analyzer layer** (`analyzers/`). `BaseAnalyzer` contract enforces a
  uniform per-analyzer `IntegrityReport` shape. `ZahirTextAnalyzer` and
  `BatinObjectAnalyzer` port every detection mechanism from v0.1.
  `AnalyzerRegistry` composes registered analyzers into one merged report
  with the `scan_incomplete` clamp applied post-merge.
- **Application layer** (`application/`). `ScanService` orchestrator:
  file-exists short-circuit → pymupdf preflight → dispatch to the
  registry. Byte-identical behaviour to `bayyinah_v0_1.scan_pdf` across
  every Phase 0 fixture.
- **Test corpus**. 500+ pytest cases across domain, infrastructure,
  analyzers, application, and integration suites. Every Phase 0 fixture
  is asserted for exact mechanism firings, score, error text, and
  scan_incomplete flag against both v0 and v0.1.

### Changed

- `[project.scripts] bayyinah` now points to `cli.main:main` (was
  `bayyinah_v0_1:main`). The `bayyinah_v0` and `bayyinah_v0_1` module-level
  `main` functions remain callable for downstream pins.

### Preserved (Additive-Only Invariant)

- `bayyinah_v0.py` and `bayyinah_v0_1.py` are unchanged. Both remain in
  the wheel as reference implementations. No line was added, removed, or
  modified in either file during the 0.2.0 refactor. Module mtimes
  verified after each phase.

### Architectural References

- [Munafiq Protocol — Detecting Performed Alignment in Artificial
  Systems](https://doi.org/10.5281/zenodo.19677111) (DOI:
  10.5281/zenodo.19677111). The scanner's scoring model (APS-continuous,
  three validity tiers, tamyiz verdict) is a direct port of §9's
  input-layer framing from LLMs to files.
- Internal roadmap: `NAMING.md` captures the Al-Baqarah phase mapping.

## [0.1.0] — 2026-04-22

### Added

- `bayyinah_v0.py` — the original monolithic scanner. Detects:
  - Text-layer mechanisms: `zero_width_chars`, `tag_chars`, `bidi_control`,
    `homoglyph`, `invisible_render_mode`, `microscopic_font`,
    `white_on_white_text`, `overlapping_text`.
  - Object-layer mechanisms: `javascript`, `openaction`,
    `additional_actions`, `launch_action`, `embedded_file`,
    `file_attachment_annot`, `incremental_update`, `metadata_anomaly`,
    `hidden_ocg`, `tounicode_anomaly`.
- `bayyinah_v0_1.py` — fat-split intermediate introducing `PDFContext`,
  `BaseAnalyzer`, `TextLayerAnalyzer`, `ObjectLayerAnalyzer`,
  `ScanService`. Byte-identical output to v0 across the fixture corpus.
- Phase 0 fixture corpus (`tests/fixtures/`): `clean.pdf`,
  `positive_combined.pdf`, 8 text-layer fixtures, 7 object-layer fixtures.
  Each fires exactly its declared mechanism set under v0.

---

**License:** Apache-2.0. See `LICENSE` for the full text. Anthropic's
usage-policies apply when running Bayyinah as an agent tool; see
project README.
