# Bayyinah

**Clear evidence for digital integrity.**

Bayyinah is an open-source file integrity scanner that extracts every content layer from a document — visible and invisible — and reports whether what the file *displays* matches what the file *contains*. It is the input-layer application of the [Munafiq Protocol](https://doi.org/10.5281/zenodo.19677111)'s performed-alignment detection: a document that renders cleanly at the surface while carrying concealed payloads, steganographic encoding, embedded prompt injections, or cross-modal anomalies is a document *performing* integrity. Bayyinah makes the performance visible; the reader performs the recognition.

[![License: Apache 2.0](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://www.apache.org/licenses/LICENSE-2.0)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![DOI](https://img.shields.io/badge/DOI-10.5281%2Fzenodo.19677111-blue)](https://doi.org/10.5281/zenodo.19677111)
[![Version](https://img.shields.io/badge/version-1.0.0-green.svg)](CHANGELOG.md)

---

## Why Bayyinah

Modern documents are a surface and a substrate. The surface is what a user sees when they open the file; the substrate is what a parser, a mail gateway, or a language model actually ingests. Adversarial documents exploit the gap between the two — zero-width characters that rewrite the meaning of a contract while leaving its rendering untouched, a PDF whose object graph carries a JavaScript action the viewer never shows, a spreadsheet whose hidden sheet holds the figures the visible sheet disguises, an email whose `From` header says one thing and whose `Return-Path` says another.

Bayyinah scans that substrate. It applies the same question to eleven file formats: **does the outward display correspond to the inner content, or has the inner content been performed into a display that hides it?**

---

## What Bayyinah detects

Two concealment *loci*, mapped onto the classical distinction between *zahir* (the outward / rendered) and *batin* (the inner / structural):

**Zahir — the text layer (what the reader sees vs. what the parser extracts)**

Zero-width characters, Unicode TAG characters (U+E0000–U+E007F), bidirectional-control overrides, homoglyph / mixed-script substitution, invisible render modes (3, 7), microscopic fonts, white-on-white text, overlapping / stacked text.

**Batin — the object layer (what ships inside the file's structural graph)**

Embedded JavaScript, `/OpenAction`, `/AA` additional actions, `/Launch` actions, embedded files and FileAttachment annotations, incremental updates (prior revisions still present), metadata anomalies (ModDate preceding CreationDate), hidden Optional Content Groups, adversarial `/ToUnicode` CMaps mapping visible glyphs to zero-width, bidi, TAG, or homoglyph codepoints.

---

## Supported formats

| Format | Analyzer | Representative mechanisms |
|--------|----------|---------------------------|
| PDF | `ZahirTextAnalyzer` + `BatinObjectAnalyzer` | every text-layer + object-layer mechanism above |
| DOCX | `DocxAnalyzer` | tracked changes, comments, hidden text, OLE, external-target relationships |
| HTML | `HtmlAnalyzer` | CSS-hidden text, off-screen absolute positioning, `<script>` / `on*` handlers, data-URI payloads |
| XLSX | `XlsxAnalyzer` | hidden sheets / rows / columns, white-on-white cells, formula injection, external links |
| PPTX | `PptxAnalyzer` | hidden slides, off-canvas shapes, embedded OLE, speaker-notes payloads |
| EML | `EmlAnalyzer` | bodyless envelopes, mismatched `From` / `Return-Path`, suspicious attachments, nested `message/rfc822` |
| CSV | `CsvAnalyzer` | formula injection (`=`, `+`, `-`, `@`, tab / CR prefixes), Unicode concealment in cells |
| JSON | `JsonAnalyzer` | prompt-injection strings, base64 blobs, zero-width / TAG characters in values |
| Markdown / code / plain text | `TextFileAnalyzer` | zero-width, TAG, bidi control, homoglyphs, invisible HTML spans |
| PNG / JPEG / GIF / BMP / TIFF / WebP | `ImageAnalyzer` | LSB steganography, trailing payloads, EXIF anomalies, embedded text layers |
| SVG | `SvgAnalyzer` | `<script>` tags, `on*` handlers, external-ref `<use>`, foreign-object HTML, off-screen text |
| **Unknown** | `FallbackAnalyzer` | emits `unknown_format` with magic-byte prefix, extension, size, head-preview — no file slips through silent-clean |

Polyglot mismatches (e.g. a `.pdf` whose bytes are really a ZIP container) are flagged by `FileRouter` at dispatch time, before any analyzer runs.

---

## Install

```bash
# From the shipped wheel
pip install bayyinah-1.0.0-py3-none-any.whl

# Or from source
git clone https://github.com/RootandRitualHerbCo/Bayyinah-v1.0-Open-Source-.git
cd Bayyinah-v1.0-Open-Source-
pip install -e '.[dev]'
```

Runtime dependencies: `pymupdf>=1.24`, `pypdf>=4.0`. Python 3.10 or newer.

---

## Quick start

Scan a file from the shell — point it at any supported format:

```bash
bayyinah scan contract.pdf              # PDF: text-layer + object-layer
bayyinah scan invoice.docx              # Word: tracked changes, comments, OLE
bayyinah scan dashboard.xlsx            # Excel: hidden sheets, formula injection
bayyinah scan page.html --summary       # HTML: off-screen text, handlers
bayyinah scan inbound.eml --json        # EML: mismatched headers, attachments
bayyinah scan unknown.widget            # Unknown format → fallback witness
```

Or from Python:

```python
from bayyinah import scan_pdf, format_text_report, ScanLimits, ScanService

# Default: PDF on default limits.
report = scan_pdf("contract.pdf")
print(report.integrity_score)              # 0.873
print([f.mechanism for f in report.findings])
# ['additional_actions']

# Any format, any configured ceiling.
svc = ScanService(limits=ScanLimits(max_file_size_bytes=10 * 1024 * 1024))
report = svc.scan("inbound.eml")
print(format_text_report(report))
```

Exit code convention (stable across versions, CI-safe):

| Code | Meaning |
|------|---------|
| `0`  | Scan completed; zero findings |
| `1`  | Scan completed; one or more findings |
| `2`  | Scan did not complete (file missing, unparseable, …) |

---

## Scoring model

Bayyinah reports an **APS-continuous integrity score** on `[0.0, 1.0]`:

```
score = clamp(1.0 − Σ(severity × confidence), 0, 1)
```

Each finding contributes a continuous deduction proportional to the concealment mass it represents (severity) scaled by the detector's confidence it fired correctly. The score saturates at `0.0`; it does not go negative. Whenever any analyzer reports incomplete coverage, the score is clamped to `0.5` — the reader cannot infer cleanness from the absence of findings in regions that were not inspected.

Every finding carries one of three validity tiers:

- **Tier 1 — verified.** Unambiguous concealment (TAG characters present; a `/JS` action in the catalog). Machine-checkable.
- **Tier 2 — structural.** A structural anomaly whose meaning depends on context (a font ToUnicode CMap that maps to a zero-width codepoint is concealment; mapped to a Latin homoglyph it is deception, but the CMap itself is structural).
- **Tier 3 — interpretive.** The signal is present but its interpretation rests on the reader (an incremental-update trail is not itself adversarial; the question is what the prior revision contained).

The scanner never issues a moral verdict on its own. It surfaces mechanisms; the reader performs the recognition.

---

## Verdict taxonomy

Each scan resolves to one of five verdicts:

| Verdict | Meaning |
|---------|---------|
| **Sahih** (صحيح — sound) | Zero findings; full inspection completed |
| **Mushtabih** (مشتبه — doubtful) | Findings present, but tier-3 / interpretive only |
| **Mukhfi** (مخفي — concealed) | Tier-1 or tier-2 concealment confirmed |
| **Munafiq** (منافق — performed) | Multiple mechanisms across both loci; the surface and the substrate diverge by design |
| **Mughlaq** (مغلق — closed) | Scan could not complete; integrity cannot be asserted either way |

Verdicts are descriptive, not normative. The tool's job is evidence; the human's job is judgment.

---

## Unknown files — the fallback witness

A file whose bytes no magic prefix recognised and whose extension no map entry covered used to slip through as silent-clean (score 1.0, zero findings — the classical Munafiq Protocol failure mode). In 1.0 the `FallbackAnalyzer` is the witness of last resort: every such file surfaces an `unknown_format` finding carrying the metadata a forensics reader needs to begin their own classification — declared extension, file size, magic-byte prefix (hex), and head-preview (first 512 bytes in both hex and printable-ASCII). The scan is marked `scan_incomplete=True` so the 0.5 clamp applies. *Absence of findings in a file we could not identify is not evidence of cleanness.*

---

## Configuration — `ScanLimits`

Every capacity ceiling the scanner applies is declared once on a frozen `ScanLimits` dataclass. Defaults are conservative (a 256 MB file ceiling, 200 000 CSV rows, etc.); override them per-service when you need tighter bounds for untrusted input or looser ones for a trusted batch pipeline.

| Field | Default | Effect when exceeded |
|-------|---------|----------------------|
| `max_file_size_bytes` | 256 MB | Short-circuits before any analyzer; emits `scan_limited`, clamps score to 0.5 |
| `max_recursion_depth` | 5 | Stops nested-message walk; emits `scan_limited` |
| `max_csv_rows` | 200 000 | Stops row iteration; findings from rows 0..ceiling retained |
| `max_field_length` | 4 MiB | Skips Unicode scan on oversized cells |
| `max_eml_attachments` | 64 | Skips attachment scan past ceiling |

Any ceiling set to `0` opts out. Ceilings apply per-scan via a thread-local `limits_context`, so concurrent scans with different limits cannot clobber each other. Every analyzer that hits a ceiling emits a `scan_limited` finding (tier 3, severity 0.0 — non-deducting), sets `scan_incomplete=True`, and returns whatever findings it already gathered. The scanner degrades gracefully; it does not crash on pathologically-large inputs.

---

## Why this matters for AI safety

Bayyinah was built for a world in which AI systems increasingly ingest documents without a human in the loop. A retrieval-augmented language model, an automated claims pipeline, a compliance agent — each of these reads files the way a parser reads them, not the way a rendering engine displays them. That asymmetry is the attack surface for indirect prompt injection, concealed payloads, and document-borne misalignment.

Bayyinah sits in front of any such pipeline as a pre-ingest integrity gate. A three-line integration:

```python
from bayyinah import ScanService, VERDICT_SAHIH

report = ScanService().scan(path)
if report.verdict != VERDICT_SAHIH:
    reject_or_route(path, report)
```

The scanner serves both human and AI integrity: protecting users from adversarial inputs, and providing verifiable evidence of what a file actually contains before it enters a system that cannot always tell the difference.

---

## Architecture

Bayyinah 1.0 is organised as a set of cooperating layers — each analyzer applies the same standard and reports in the same shape:

```
bayyinah/                public Python API (scan_pdf, ScanService, …)
cli/                     console script (bayyinah CLI)
application/             ScanService orchestrator
analyzers/               BaseAnalyzer contract + Zahir/Batin analyzers
infrastructure/          PDFClient, FileRouter, formatters
domain/                  pure Finding / IntegrityReport / scoring primitives
```

The reference implementation is preserved unchanged at `bayyinah_v0.py` and its fat-split intermediate at `bayyinah_v0_1.py`; both ship in the wheel. The parity invariant — `bayyinah.scan_pdf == bayyinah_v0.scan_pdf` on every reference fixture — is asserted by the integration test suite and held across the full modular refactor. Byte-identical parity is verified in CI.

---

## Development

```bash
# Install with dev extras
pip install -e '.[dev]'

# Generate fixture corpus (one-time)
python -m tests.make_test_documents

# Run the full suite
pytest

# Scan a file directly from source tree
python -m cli.main scan path/to/file.pdf
```

1280+ pytest cases across domain, infrastructure, analyzers, application, fixture corpora, and end-to-end integration. Every reference fixture is asserted for exact mechanism firings, score, error text, and `scan_incomplete` flag — against both `bayyinah_v0.py` and `bayyinah_v0_1.py`. Byte-identical PDF parity with the reference implementation is re-verified after every change; the invariant has held across every release.

---

## Academic reference

If you use Bayyinah in published work, please cite the underlying protocol:

> **Munafiq Protocol — Detecting Performed Alignment in Artificial Systems.**
> DOI: [10.5281/zenodo.19677111](https://doi.org/10.5281/zenodo.19677111)

The scanner's scoring model, validity tiers, and verdict taxonomy are a direct port of §9's input-layer framing from language models to files. Accompanying papers — a white paper describing the detection architecture and a thesis paper providing a case study and defense for AI-safety integration — are included in the `papers/` directory of this release.

---

## Contributing

Contributions are welcome. See [CONTRIBUTING.md](CONTRIBUTING.md) for the development workflow, the additive-only public-surface invariant, the parity test requirement, and the fixture-regeneration discipline. Before submitting a pull request: run `pytest`, confirm byte-identical parity against the reference modules, and verify the public surface has only grown.

---

## License

Apache 2.0. See [LICENSE](LICENSE) for full text and [CHANGELOG.md](CHANGELOG.md) for version history.

---

*Bayyinah* (بَيِّنَة) — "clear evidence."
